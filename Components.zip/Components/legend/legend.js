// legend.js

import { loadRoleData , roles} from '../../js/loader/role-loader.js';
import { loadEmployeeData, employees } from '../../js/loader/employee-loader.js';

document.addEventListener('DOMContentLoaded', () => {
  // Use Promise.all to load both role and employee data
  Promise.all([loadRoleData(), loadEmployeeData()])
    .then(() => {
      // Once both data sets are loaded, initialize the legend
      initializeLegend();
    })
    .catch((error) => {
      console.error('Error loading data:', error);
    });
});

function initializeLegend() {
  const legendContainer = document.getElementById('legend');
  if (!legendContainer) return console.error('Legend container not found');

  legendContainer.style.overflow = 'auto'; // Allow scrollbars for overflow
  legendContainer.innerHTML = ''; // Clear any existing content
  renderCollapsibleSection(legendContainer, '🎨 ⇨ Rolle/ Aufgabe', renderRoles);
  renderCollapsibleSection(legendContainer, '😊 ⇨ Mitarbeiter', renderEmployees);
}


function renderCollapsibleSection(container, title, renderContentFunction) {
  // Create collapsible button
  const collapsibleButton = document.createElement('button');
  collapsibleButton.classList.add('collapsible');

  // Create and append the icon
  const icon = document.createElement('img');
  icon.src = '/assets/svg/next-svgrepo-com.svg'; // Path to the SVG icon
  icon.alt = `${title} Icon`;
  icon.classList.add('collapsible-icon');

  collapsibleButton.appendChild(icon);

  // Add the title text
  const titleText = document.createElement('span');
  titleText.innerText = title;
  collapsibleButton.appendChild(titleText);

  // Create collapsible content wrapper
  const collapsibleContent = document.createElement('div');
  collapsibleContent.classList.add('collapsible-content');

  // Render specific content inside collapsible
  renderContentFunction(collapsibleContent);

  // Append to container
  container.appendChild(collapsibleButton);
  container.appendChild(collapsibleContent);

  // Add click event to toggle visibility and rotation
  collapsibleButton.addEventListener('click', () => {
    const isVisible = collapsibleContent.style.display === 'block';
    collapsibleContent.style.display = isVisible ? 'none' : 'block';
    collapsibleButton.classList.toggle('active', !isVisible);
  });
}

function renderRoles(container) {
  const list = document.createElement('ul');
  list.classList.add('legend-list');

  // Loop through the roles array that was loaded from CSV
  roles.forEach(role => {
    if (role.emoji === "❓") return;
    if (role.name === 'keine') return;
    if (role.name === '?') return; // Skip roles with '?' as name
    if (role.name === "name") return;
    
    // Create list item for role
    const listItem = document.createElement('li');
    listItem.classList.add('legend-item', 'role');
    
    // Set background color based on role's color index
    const roleColor = getComputedStyle(document.documentElement)
      .getPropertyValue(`--role-${role.colorIndex}-color`);

    listItem.style.backgroundColor = roleColor; // Apply background color from CSS variables

    // Create the emoji span
    const emoji = document.createElement('span');
    emoji.classList.add('legend-icon');
    emoji.innerText = role.emoji;

    // Create the role name span
    const roleName = document.createElement('span');
    roleName.classList.add('legend-name');
    roleName.innerText = ` ⇨ ${role.name}`;

    // Append emoji and role name to list item
    listItem.appendChild(emoji);
    listItem.appendChild(roleName);
    
    // Append list item to the list
    list.appendChild(listItem);
  });

  // Append the list to the container
  container.appendChild(list);
}

function renderEmployees(container) {
  const list = document.createElement('ul');
  list.classList.add('legend-list');

  // Loop through the roles array that was loaded from CSV
  employees.forEach(employee => {
    if (employee.name === '?') return; // Skip roles with '?' as name
    if (employee.name === "name") return;
    
    // Create list item for role
    const listItem = document.createElement('li');
    listItem.classList.add('legend-item', 'employee');
    
    // Set background color based on role's color index
    const roleColor = getComputedStyle(document.documentElement)
      .getPropertyValue(`--role-${employee.mainRoleIndex}-color`);

    listItem.style.backgroundColor = roleColor; // Apply background color from CSS variables

    // Create the emoji span
    const emoji = document.createElement('span');
    emoji.classList.add('legend-icon');
    emoji.innerText = employee.personalEmoji;

    // Create the role name span
    const employeeName = document.createElement('span');
    employeeName.classList.add('legend-name');
    employeeName.innerText = ` ⇨ ${employee.name}`;

    // Append emoji and role name to list item
    listItem.appendChild(emoji);
    listItem.appendChild(employeeName);
    
    // Append list item to the list
    list.appendChild(listItem);
  });

  // Append the list to the container
  container.appendChild(list);
}
