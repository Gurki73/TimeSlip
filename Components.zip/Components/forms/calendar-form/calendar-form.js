/**
 * ================================
 * Besondere Tage: Dialects & Schützenfest (Future Enhancements)
 * ================================
 * 
 * Summary:
 * We've brainstormed unique and regionalized titles/tooltips for "Besondere Tage"
 * that reflect the local flavor and culture. These playful additions 
 * (especially in dialects!) aim to make the app feel more personal and fun 
 * for users, even though they are not strictly necessary for functionality.
 * 
 * The idea is to go beyond functionality to delight users, showing "love" 
 * in small ways that could enhance brand perception.
 * 
 * Dialect-Specific Tooltip Examples:
 * ----------------------------------
 * 1. Bavaria: "Hier feiern wir gern doppelt" (Playful Bavarian tone)
 * 2. Thuringia: "Hexen in der Walpurgisnacht" (Highlighting Walpurgisnacht)
 * 3. Berlin: "FeiertagsVibes: Extra-Tage im Kalender" (Urban/modern vibe)
 * 4. Baden-Württemberg: "Deine goldenen Gelegenheiten" (Sophisticated mood)
 * 5. NRW: "Heimliche Favoriten im Kalender" (Playful but simple)
 * 6. Hesse: "Feiertags-Upgrades" (Concise and upbeat)
 * 7. Default: "Brückentage und Besondere Tage" (Neutral fallback)
 * 
 * Schützenfest:
 * -------------
 * We decided to add Schützenfest as a regional celebration for:
 *  - North Rhine-Westphalia
 *  - Lower Saxony
 * 
 * Emoji: 🎯 (target), 🔫 (toy gun), or 🥨 (festive pretzel vibe).
 * Timing: Tentative default to July 15th for simplicity (could be refined to 
 * actual festival dates or calculated dynamically later).
 * Tooltips:
 *  - NRW: "Treffsicher durch den Sommer – Schützenfestzeit!"
 *  - Lower Saxony: "Zielen, Feiern und Gemeinschaft – unser Schützenfest."
 */
import { loadCalendarData, saveStateData, state, companyHolidays, officeDays, schoolHoliday } from '../../../js/loader/calendar-loader.js';
import { getHolidayDetails, getAllHolidaysForYear, nonOfficialHolidays, monthNames, germanFixedHolidays, germanVariableHolidays } from '../../../js/Utils/holidayUtils.js';
import { stateFlags, updateStateFlag } from '../../../js/Utils/flagUtils.js';

let currentYear = new Date().getFullYear();

document.addEventListener('DOMContentLoaded', () => {
  initializeStateFlagUpdater();
});

function handleStateChange(event) {
  const selectedState = event.target.value; 
  const stateFlagElement = document.getElementById('calendar-form-state-flag');
  
  if (stateFlagElement) {
    updateStateFlag(selectedState, stateFlagElement);
  } else {
    console.error('State flag element not found!');
  }
  saveStateData(selectedState);
}

function initializeStateFlagUpdater() {
  const stateSelect = document.getElementById('state-select');
  if (stateSelect) {
    stateSelect.addEventListener('change', handleStateChange); 
  } else {
    updateFeedback('State select element not found!');
  }
}

export function initializeCalendarForm() {
  
  const stateSelect = document.getElementById('state-select');
  const stateFlagElement = document.getElementById('calendar-form-state-flag');
  const prevYearButton = document.getElementById('calendar-form-prev-year');
  const nextYearButton = document.getElementById('calendar-form-next-year');
  const yearSpan = document.querySelector('#current-year h2');

  if (yearSpan) {
    yearSpan.textContent = currentYear; // Set the year span to the current year
  } else {
    updateFeedback('Year span element not found!');
  }

  if (prevYearButton && nextYearButton) {
    prevYearButton.addEventListener('click', decreaseYear);
    nextYearButton.addEventListener('click', increaseYear);
  } else {
    updateFeedback('Year buttons not found!');
  }
  function decreaseYear() {
    currentYear--;
    updateYearDisplay();
    updateHolidaysForYear(currentYear);
  }
  
  function increaseYear() {
    currentYear++;
    updateYearDisplay();
    updateHolidaysForYear(currentYear);
  }
  
  function updateYearDisplay() {
    const yearSpan = document.querySelector('#current-year h2');
    if (yearSpan) {
      yearSpan.textContent = currentYear; // Update the year span
    } else {
      console.error('Year span element not found!');
    }
    updateHolidaysForYear(currentYear);
  }
  if (!stateSelect || !stateFlagElement) {
    updateFeedback('State select or state flag element not found!');
    return;
  }
  stateSelect.value = state;
  updateStateFlag(state, stateFlagElement);
  initializeStateFlagUpdater();
  updateHolidaysForYear(currentYear);
}

function updateHolidaysForYear(year) {
  try {
    const data = getAllHolidaysForYear(year, state);
    updateFeedback(`Holidays for ${year}:`, data);
    
    const holidayList = document.getElementById('public-holidays');
    if (!holidayList) {
      console.error('Holiday list container not found!');
      return;
    }
    
    holidayList.innerHTML = '';

    data.forEach(holiday => {
      const [year, month, day] = holiday.date.split('-');
      const formattedDate = `${String(day).padStart(2, '0')}.${String(month).padStart(2, '0')}.${year}`;
      const listItem = document.createElement('li');
      
      listItem.textContent = `${formattedDate}   ${holiday.emoji}   ⇨   ${holiday.name}`;
      holidayList.appendChild(listItem);
    });

    console.log(data);
  } catch (error) {
    updateFeedback('Failed to load holidays:', error);
  }
}





 
  