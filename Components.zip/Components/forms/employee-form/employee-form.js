import { loadRoleData , roles} from '../../../js/loader/role-loader.js';
import { loadEmployeeData, employees } from '../../../js/loader/employee-loader.js';
import { createEmojiPicker } from '../../../Components/emojiPicker/emojiPicker.js';
import { loadCalendarData, state, companyHolidays, officeDays, schoolHoliday } from '../../../js/loader/calendar-loader.js';

const employeeEmojiOptions = [
    "⚽️", "🏀", "🏈", "🎾", "🐶", "🐱", "🐻", 
    "🐼", "🦁", "🐸", "🐦", "🦋", "🌷", "🌵", 
    "🍀", "🌸", "🌻", "🧩", "🎯", "🪁", "🏓", 
    "🍎", "🍕", "🥗", "🍫", "🐢", "🦄", "🐒", 
    "🌿", "🍌", "🍒", "🍇", "🍉", "🍓", "🥝", 
    "☕", "🧢", "👢", "🧥", "🍏", "👜", "💍", 
    "🪭", "❤️", "🏆", "👑", "🌞", "🌧️", "🌙"  
];
const employeeEmojis = [...employeeEmojiOptions]; 

let employeeFormDataChanged = false;
let employeeFormDataNew = false;

function deleteEmoji(emoji) {
  const index = employeeEmojiOptions.indexOf(emoji);
  if (index > -1) {
    employeeEmojiOptions.splice(index, 1);
  } else {
    updateFeedback(`Emoji "${emoji}" not found in the available list.`);
  }
}

function addEmoji(emoji) {
  if (emoji === "❓") return;
  if (!employeeEmojiOptions.includes(emoji)) {
    employeeEmojiOptions.push(emoji);
  } else {
    console.warn(`Emoji "${emoji}" is already in the available list.`);
  }
}

function changeEmployeeEmoji(employee, newEmoji) {
  const oldEmoji = employee.personalEmoji;

  deleteEmoji(newEmoji);
  addEmoji(oldEmoji);
  employee.personalEmoji = newEmoji;
}

function bindEmojiPickerToEmployee(employee  ) {

  const handleEmployeeEmojiSelectionChange = (selectedEmoji) => {
    if (selectedEmoji) {
      console.log(`Selected emoji for employee ${employee.name}:`, selectedEmoji);

      const oldEmoji = employee.personalEmoji;
      employee.personalEmoji = selectedEmoji;

      if (oldEmoji) addEmoji(oldEmoji);
      deleteEmoji(selectedEmoji);

      renderEmployeeList();
      updateFeedback(`Emoji for ${employee.name} updated to ${selectedEmoji}`);
    } else {
      console.log(`No emoji selected for employee ${employee.name}.`);
    }
  };
  const emojiButton1 = document.getElementById('employee-emoji-picker-btn');
  createEmojiPicker(employeeEmojiOptions, emojiButton1, employee.mainRoleIndex, handleEmployeeEmojiSelectionChange);
}


function validateEmployeeData(employees) {
  const errors = [];
  employees.forEach((employee, index) => {
    const { id, name, emoji, mainRoleIndex } = employee;

    if (!name) errors.push(`Employee at index ${index} is missing a name.`);
    if (mainRoleIndex === undefined) errors.push(`Employee ${name || `at index ${index}`} is missing a main role.`);
    if (!emoji) errors.push(`Employee ${name || `at index ${index}`} is missing an emoji.`);

    employee.secondaryRoleIndex = employee.secondaryRoleIndex ?? null;
    employee.tertiaryRoleIndex = employee.tertiaryRoleIndex ?? null;
    employee.availableDaysOff = employee.availableDaysOff ?? 30.0;
    employee.remainingDaysOff = employee.remainingDaysOff ?? 30.0;
    employee.overtime = employee.overtime ?? 0.0;
    employee.startDate = employee.startDate ?? new Date().toISOString().split('T')[0];
    employee.endDate = employee.endDate ?? null;
    employee.teamIndex = employee.teamIndex ?? null;
    employee.shiftType = employee.shiftType ?? 'full';
    employee.birthday = employee.birthday ?? null;
  });

  if (errors.length > 0) {
    updateFeedback("Validation errors found:", errors);
  }
}

export function initializeEmployeeForm() {
  const container = document.getElementById('employee-form-container');
  if (!container) return console.error('Employee form container not found!');

  container.innerHTML = '';

  renderPrivacyColumn(container);

   loadEmployeeData().then(() => {
    renderEmployeeListColumn(container);
    renderEmployeeList(); 
    renderDetailColumn(container);
    selectEmployee(employees[0]);
  }).catch(error => {
    console.error('Failed to load employee data:', error);
    updateFeedback(container, 'Failed to load employee data. Please try again later.');
  });
}

function renderPrivacyColumn(container) {
  const privacyColumn = document.createElement('div');
  privacyColumn.id = 'privacy-warning-panel';
  privacyColumn.className = 'form-column';
  privacyColumn.innerHTML = `
    <p>
      ⚠️ <b>Datenschutzhinweis:</b> Beachten Sie, dass diese Anwendung sensible Daten enthält. 
      Bitte stellen Sie sicher, dass die Daten gemäß den gesetzlichen Bestimmungen geschützt sind.
    </p>
    <p>
      Diese Anwendung ist nur für autorisierte Benutzer bestimmt. Eine unsachgemäße Verwendung kann rechtliche Konsequenzen haben.
    </p>
  `;
  container.appendChild(privacyColumn);
}

function renderEmployeeListColumn(container) {
  const listColumn = document.createElement('div');
  listColumn.id = 'employee-list-column';
  listColumn.innerHTML = `
    Mitarbeiter - Auswahl
    <div style="padding-left:10px; padding-right:10px; padding-top:10px;">
    <div class="employee-item" id="employeeForm-new-btn">
      <span span="employee-item" style="color: black; margin: 15px;">
        <span class="employee-emoji" style="background-color: lightgray">❓</span>
        <span>
           ⇨ neuer Mitarbeiter 
        </span>
      </span>  
    </div>
    </div>
    <ul id="employee-list" class="employee-list"></ul>
  `;
  container.appendChild(listColumn);

  const newEmployeeBtn = document.getElementById('employeeForm-new-btn');
  if (newEmployeeBtn) {
      newEmployeeBtn.addEventListener('click', createNewEmployee);
  }
}
function createNewEmployee() {
  employeeFormDataNew = true;

  updateFeedback("new employee btn clicked");
  const lastIndex = employees.length -1;
  const lastEmployee = employees[lastIndex];

  if (isValidEmployeeEmoji(lastEmployee.personalEmoji, null)) {
    selectEmployee(lastIndex);
    return;
  }
  if (isValidEmployeeName(lastEmployee.name), null) {
    selectEmployee(lastIndex);
    return;
  }
  if (isValidEmployeeMainRoleIndex(lastEmployee.mainRoleIndex), null) {
    selectEmployee(lastIndex);
    return;
  }
  const today = new Date();
  const tenYearsLater = new Date();
  tenYearsLater.setFullYear(today.getFullYear() + 10)
  
    const newEmployee = {
      id: lastIndex+1,
      name: "neuer Mitarbeiter",
      personalEmoji: "❓", 
      mainRoleIndex: -1, 
      secondaryRoleIndex: -1,
      tertiaryRoleIndex: -1,
      availableDaysOff: 30,
      remainingDaysOff: 30,
      overtime: 0,
      workDays: [
       officeDays[0] != "never" , // Mo
       officeDays[1] != "never" , // Di
       officeDays[2] != "never" , // Mi
       officeDays[3] != "never" , // Do
       officeDays[4] != "never" , // Fr
       officeDays[5] != "never" , // Sa
       officeDays[6] != "never" , // So
      ],
      roleSplitMain: 100,
      roleSplitSecondary: 0,
      roleSplitTertiary: 0,
      startDate: today, 
      endDate: tenYearsLater, 
      teamIndex: null, 
      shiftType: "ganztag", 
      birthday: "00.00", 
      shifts: { 
          mon: officeDays[0],
          tue: officeDays[1],
          wed: officeDays[2],
          thu: officeDays[3],
          fri: officeDays[4],
          sat: officeDays[5],
          sun: officeDays[6]
      }
  };

  employees.push(newEmployee);
  selectEmployee(newEmployee );
}

function renderDetailColumn(container) {
  const detailColumn = document.createElement('div');
  detailColumn.id = 'employee-details-column';
  detailColumn.className = 'form-column';
  detailColumn.innerHTML = `
    <form id="employee-details-form">
      <!-- Form fields will be dynamically populated here -->
    </form>
  `;
  container.appendChild(detailColumn);

  const employeeFormNew = document.getElementById('employee-details-form');
}

function renderEmployeeList() {
  const listContainer = document.getElementById('employee-list');
  if (!listContainer) return console.error('Employee list container not found!');

  listContainer.innerHTML = ''; 

  employees.forEach(employee => {
    
    deleteEmoji(employee.personalEmoji);
    const listItem = document.createElement('li');
    listItem.classList.add('employee-item');

    const emojiElement = document.createElement('span');
    emojiElement.classList.add('employee-emoji');
    emojiElement.textContent = employee.personalEmoji;

    emojiElement.setAttribute('data-role', employee.mainRoleIndex);

    listItem.appendChild(emojiElement);
    listItem.appendChild(document.createTextNode(" ⇨ " + employee.name));

    listItem.addEventListener('click', () => selectExsitingEmployee(employee));
    listContainer.appendChild(listItem);
  });
}

function selectExsitingEmployee(employee) {
  employeeFormDataNew = false;
  selectEmployee(employee);
}

function isValidEmployeeEmoji(emoji, emojiField) {
  const isValid = emoji !== "❓";
  if(emojiField) emojiField.classList.toggle('invalid-field', !isValid);
  return isValid;
}

function isValidEmployeeName(name, nameField) {
  const isValid = name !== "name" &&
                  name !== "" && 
                  name !== "neuer Mitarbeiter" &&
                  name !== "undefined" &&
                  name !== null;
  if (nameField) nameField.classList.toggle('invalid-field', !isValid);
  return isValid;
}

function isValidEmployeeMainRoleIndex(mainRoleIndex, mainRoleField) {
  const isValid = mainRoleIndex >= 0 && mainRoleIndex <= 11;
  if (mainRoleField) mainRoleField.classList.toggle('invalid-field', !isValid);
  return isValid;
}



function selectEmployee(employee) {
  const form = document.getElementById('employee-details-form');
  if (!form){
    updateFeedback('Employee details form not found!');
    return;
  } 

  form.innerHTML = `
    <div>
      <div class="employee-detail-top-row">
        <button class="mybutton-small reset-button" type="button" title="Rückgängig">⤺</button>
        <button class="mybutton-small delete-button" type="button" title="Mitarbeiter löschen">🚮</button>
        <button class="mybutton-small store-button" type="button" title="Änderungen speichern">💾</button>
      </div>
      <div id="employee-details-left">
        <div style="margin:15px; padding:10px;">
            <div style="display: flex; align-items: center; gap: 8px;">
              <button id="employee-emoji-picker-btn" style="background-color: var(--role-${employee.mainRoleIndex}-color);">
                ${employee.personalEmoji || '❓'}
              </button>
              <input type="text" id="employee-name" value="${employee.name}" style="flex-grow: 1;" />
            </div>
            
            <div class="employee-detail-date-row">
              Urlaubsanspruch: 
              <input type="number" id="employee-remaining" value="${employee.remainingDaysOff}" style="flex-grow: 1;" />
              /
              <input type="number" id="employee-available" value="${employee.availableDaysOff}" style="flex-grow: 1;" />
              Überstunden:
              <input type="number" id="employee-overtime" value="${employee.overtime}" style="flex-grow: 1;" />
            </div>

            <div style="margin-top: 16px;">
              <select id="main-role" style="background-color: var(--role-${employee.mainRoleIndex}-color);">
                ${roles.map((role, index) => `
                  <option value="${index}" style="background-color: var(--role-${index}-color);" ${employee.mainRoleIndex === index ? 'selected' : ''}>
                    ${role.emoji} ⇨ ${role.name}
                  </option>
                `).join('')}
              </select>
            </div>

            <div style="margin-top: 8px;">
              <select id="secondary-role" style="background-color: var(--role-${employee.secondaryRoleIndex}-color);">
                ${roles.map((role, index) => `
                  <option value="${index}" style="background-color: var(--role-${index}-color);" ${employee.secondaryRoleIndex === index ? 'selected' : ''}>
                    ${role.emoji} ⇨ ${role.name}
                  </option>
                `).join('')}
              </select>
            </div>

            <div style="margin-top: 8px;">
              <select id="tertiary-role" style="background-color: var(--role-${employee.tertiaryRoleIndex}-color);">
                ${roles.map((role, index) => `
                  <option value="${index}" style="background-color: var(--role-${index}-color);" ${employee.tertiaryRoleIndex === index ? 'selected' : ''}>
                    ${role.emoji} ⇨ ${role.name}
                  </option>
                `).join('')}
              </select>
            </div>
          </div>
          
          <div id="employee-details-right">
            <div class="employee-detail-date-row">
              <label>Geburtstag:</label>
              <input type="text" id="employee-birthday" placeholder="dd, mm" value="${employee.birthday || ''}" />
            </div>
            <div class="employee-detail-date-row">
              <label>Angefangen:</label>
              <input type="date" id="employee-start-date" value="${employee.startDate || ''}" />
            </div>
            <div class="employee-detail-date-row">
              <label>Austritt:</label>
              <input type="date" id="employee-end-date" value="${employee.endDate || ''}" />
            </div>
            <div>
            -
            </div class="employee-detail-date-row">
            <div class="slider-container">
              <button class="slider-button less-btn" id="decrease-main-btn">❮</button>
              <div class="slider-wrapper">
                <label for="main-role-ratio" class="slider-label">Main Role Ratio:</label>
                <input type="number" id="main-role-ratio-input" value="50" min="0" max="100" step="5" readonly>
                <div class="slider-bar">
                  <div class="slider-fill" id="main-slider-fill"></div>
                </div>
              </div>
              <button class="slider-button more-btn" id="increase-main-btn">❯</button>
            </div>

            <div class="slider-container">
              <button class="slider-button less-btn" id="decrease-main-btn">❮</button>
              <div class="slider-wrapper">
                <label for="main-role-ratio" class="slider-label">Main Role Ratio:</label>
                <input type="number" id="main-role-ratio-input" value="50" min="0" max="100" step="5" readonly>
                <div class="slider-bar">
                  <div class="slider-fill" id="main-slider-fill"></div>
                </div>
              </div>
              <button class="slider-button more-btn" id="increase-main-btn">❯</button>
            </div>

            <div class="slider-container">
              <button class="slider-button less-btn" id="decrease-main-btn">❮</button>
              <div class="slider-wrapper">
                <label for="main-role-ratio" class="slider-label">Main Role Ratio:</label>
                <input type="number" id="main-role-ratio-input" value="50" min="0" max="100" step="5" readonly>
                <div class="slider-bar">
                  <div class="slider-fill" id="main-slider-fill"></div>
                </div>
              </div>
              <button class="slider-button more-btn" id="increase-main-btn">❯</button>
            </div>
          </div>        
        </div>
      </div>

      <div id="employee-form-weekdays">
      Arbeitstage
        <ul style="list-style: none; padding: 0; margin: 0;">
          ${['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map((day, index) => {
            const shift = officeDays [index] || 'ganztag'; 

            let labelClass = '';
          
            switch (shift) {
              case 'ganztag':  // Full day
                labelClass = 'weekday-full';
                break;
              case 'vormittags':  // Morning only
                labelClass = 'weekday-morning';
                break;
              case 'nachmittags':  // Afternoon only
                labelClass = 'weekday-afternoon';
                break;
              case 'niemals':  // Never
                labelClass = 'weekday-never';
                break;
              default:
                labelClass = '';  // Default class if something unexpected happens
            }
          
            return `
              <li class="weekday-row">
                <input class="weekday-checkbox" type="checkbox" id="checkbox-${day.toLowerCase()}" ${employee.availableDays?.includes(day) ? 'checked' : ''}>
                <label for="checkbox-${day.toLowerCase()}" class="${labelClass}">${day.substring(0, 2)}</label>
                <select class="weekday-dropdown">
                  <option class="weekday-option" value="ganztag" ${employee.shiftPreferences?.[day] === 'ganztag' ? 'selected' : ''}>Ganztag</option>
                  <option class="weekday-option" value="vormittags" ${employee.shiftPreferences?.[day] === 'vormittags' ? 'selected' : ''}>Vormittags</option>
                  <option class="weekday-option" value="niemals" ${employee.shiftPreferences?.[day] === 'niemals' ? 'selected' : ''}>Niemals</option>
                </select>
              </li>
            `;
          }).join('')}
        </ul>

      </div>
  `;
  const resetButton = document.querySelector('.reset-button');
  const storeButton = document.querySelector('.store-button');
  const deleteButton = document.querySelector('.delete-button');
  const employeeEmojiSelect = document.getElementById('employee-emoji-picker-btn');
  
  const employeeNameField = document.getElementById('employee-name');
  const mainRoleField = document.getElementById('main-role');

  resetButton.addEventListener('click', () => resetForm(employee));
  storeButton.addEventListener('click', () => storeFormData(employee));
  deleteButton.addEventListener('click', () => deleteEmployee(employee));
  
  employeeEmojiSelect.addEventListener('click', function() {
      bindEmojiPickerToEmployee(employee );
    });

  const emojiValid = isValidEmployeeEmoji(employee.personalEmoji, employeeEmojiSelect);
  const nameValid = isValidEmployeeName(employee.name, employeeNameField);
  const mainRoleValid = isValidEmployeeMainRoleIndex(employee.mainRoleIndex, mainRoleField);

  updateButtonVisibility(emojiValid, nameValid, mainRoleValid, employee);
}

function updateButtonVisibility(emojiValid, nameValid, mainRoleValid, employee) {
  const resetButton = document.querySelector('.reset-button');
  const storeButton = document.querySelector('.store-button');
  const deleteButton = document.querySelector('.delete-button');

  if (employeeFormDataNew) {
    deleteButton.style.display = "none";
  } else {
    deleteButton.style.display = ""; 
  }

  if (emojiValid && nameValid && mainRoleValid && employeeFormDataChanged) {
    storeButton.disabled = false;
  } else {
    storeButton.disabled = true;
  }

  if (employeeFormDataChanged) {
    resetButton.style.display = "";
  } else {
    resetButton.style.display = "none"; 
  }
}

function saveEmployee(employee) {
  const name = document.getElementById('employee-name').value;
  const emoji = document.getElementById('emoji-picker-btn').textContent;
  const mainRole = parseInt(document.getElementById('main-role').value, 10);
  const birthday = document.getElementById('employee-birthday').value;

  employee.name = name;
  employee.emoji = emoji;
  employee.mainRoleIndex = mainRole;
  employee.birthday = birthday;

  validateEmployeeData(employees);
  renderEmployeeList();
}

function deleteEmployee(employee) {
  const index = employees.indexOf(employee);
  if (index > -1) {
    employees.splice(index, 1);
    renderEmployeeList();
    document.getElementById('employee-details-form').innerHTML = '';
  }
}

function validateEmployeeForm(employee) {
  const errors = [];
  const form = document.getElementById('employee-details-form');
  
  if (!form) return console.error('Employee details form not found!');

  Array.from(form.elements).forEach(el => {
    el.style.backgroundColor = '';
    el.style.border = '';
    const errorText = el.nextElementSibling;
    if (errorText && errorText.classList.contains('error-text')) {
      errorText.remove();
    }
  });

  const nameInput = document.getElementById('employee-name');
  if (!nameInput.value.trim()) {
    addValidationError(nameInput, 'Name is required.');
    errors.push('Name is missing.');
  }

  const emojiPickerBtn = document.getElementById('emoji-picker-btn');
  if (!emojiPickerBtn.textContent || emojiPickerBtn.textContent === 'Pick Emoji') {
    addValidationError(emojiPickerBtn, 'Emoji is required.');
    errors.push('Emoji is missing.');
  }

  const mainRoleInput = document.getElementById('main-role');
  if (!mainRoleInput.value.trim()) {
    addValidationError(mainRoleInput, 'Main role is required.');
    errors.push('Main role is missing.');
  }

  const weekdayCheckboxes = form.querySelectorAll('input[name="days"]:checked');
  const weekdaysSelected = Array.from(weekdayCheckboxes).map(cb => cb.value);
  if (weekdaysSelected.includes('Sunday') && !officeDays.includes('Sunday')) {
    addValidationError(form, 'Sundays are office-closed days.');
    errors.push('Employee is scheduled to work on Sunday.');
  }

  if (employee.secondaryRoleIndex || employee.tertiaryRoleIndex) {
    const ratio = parseFloat(document.getElementById('role-ratio').value || 0);
    if (isNaN(ratio) || ratio <= 0 || ratio > 1) {
      addValidationError(
        document.getElementById('role-ratio'),
        'Secondary/Tertiary role ratio must be between 0 and 1.'
      );
      errors.push('Invalid secondary/tertiary role ratio.');
    }
  }

  if (errors.length > 0) {
    console.warn('Validation errors:', errors);
  }

  return errors.length === 0;
}

function addValidationError(element, message) {
  element.style.backgroundColor = 'yellow';
  element.style.border = '2px solid red';
  element.style.borderRadius = '4px';

  const errorText = document.createElement('div');
  errorText.classList.add('error-text');
  errorText.style.color = 'gray';
  errorText.style.fontStyle = 'italic';
  errorText.textContent = message;
  element.insertAdjacentElement('afterend', errorText);

  element.title = message;
}

function deleteCurrentEmployee() {
  updateFeedback("🚮 Delete Current Employee button clicked.");
}

function storeCurrentEmployee() {
  updateFeedback("💾 Store Current Employee button clicked.");
}
