import { loadRoleData, roles, allRoles,  generateRoleCSV } from '../../../js/loader/role-loader.js';
import { createEmojiPicker } from '../../../Components/emojiPicker/emojiPicker.js';

let roleChanges = Array(12).fill(false);
const emoji = [
  "🛠️", "📚", "💻", "🧑‍⚖️", "🚓", "🔍", "🎤",
  "🔬", "🪥", "🩺", "🧹", "🪣", "⚙️", "🧯",
  "📦", "🛒", "✂️", "🔌", "🖨️", "🎨", "📞",
  "⛑️", "🖋️", "💵", "💳", "🍲", "💪", "🔒",
  "🩻", "🦷", "💬", "📊", "🧠", "🌙", "📸",
  "🛵", "⚕️"
];

document.addEventListener('DOMContentLoaded', () => {
  Promise.all([loadRoleData()])
    .then(() => {
      renderRoleForm();
    })
    .catch((error) => {
      console.error('Error loading data:', error);
    });
});

function renderRoleForm() {
  const container = document.getElementById('role-form-container');
  container.innerHTML = '';

  const table = document.createElement('table');
  table.className = 'role-table';

  for (let row = 0; row < 3; row++) {
    const tableRow = document.createElement('tr');

    for (let col = 0; col < 4; col++) {
      const roleIndex = (row + col * 3) + 1;
      const role = allRoles[roleIndex];

      const cell = document.createElement('td');
      cell.className = 'role-cell';

      if (role) {
        const roleDiv = document.createElement('div');
        roleDiv.className = 'task-button';
        roleDiv.setAttribute('data-role', role.colorIndex || '0');

        const emojiToUse = role.emoji || emoji[roleIndex % emoji.length];
        const roleName = role.name || '';
        const deleteButtonStyle = (roleName === '?'&& emojiToUse === '❓') ? 'display: none;' : '';
        const storeButtonStyle = roleChanges[roleIndex] ? '' : 'display: none;';

        roleDiv.innerHTML = `
          ${roleIndex }.

          <button class="transparentButton emoji-button-${roleIndex}">
            ${emojiToUse}
          </button>
          ⇨
          <input class="name-role name-role-${roleIndex}" type="text" value="${roleName}" 
                 oninput="markRoleAsChanged(${roleIndex})" />

           <button class="mybutton-small delete-button-${roleIndex}" type="button" style="${deleteButtonStyle}"
           title="${(roleName)} löschen"
           >🚮</button>
          
          <button class="mybutton-small store-button-${roleIndex}" type="button" style="${storeButtonStyle}"
          title="Änderungen speichern"
          >💾</button>
        `;

        const emojiButton = roleDiv.querySelector(`.emoji-button-${roleIndex}`);
        emojiButton.addEventListener('click', () => changeEmoji(roleIndex));
         
        const inputElement = roleDiv.querySelector(`.name-role-${roleIndex}`);
        inputElement.addEventListener('keydown', (event) => handleRoleInputKeydown(event, roleIndex));

        const deleteButton = roleDiv.querySelector(`.delete-button-${roleIndex}`);
        deleteButton.addEventListener('click', () => deleteRoleAndShowStoreButton(roleIndex));

        const storeButton = roleDiv.querySelector(`.store-button-${roleIndex}`);
        storeButton.addEventListener('click', () => storeRole(roleIndex));

        cell.appendChild(roleDiv);
      }
      tableRow.appendChild(cell);
    }

    table.appendChild(tableRow);
  }

  container.appendChild(table);
}


/**
 * Handle keydown events for the role input field
 * @param {KeyboardEvent} event - The keydown event
 * @param {number} index - The index of the role
 */
function handleRoleInputKeydown(event, index) {
  if (event.key === 'Enter') {
    // Exit the input field (blur the field)
    event.target.blur();
    
    // Call a custom function when Enter is pressed
    processRoleInput(index);
  }
}
function markRoleAsChanged(index)
{
  roleChanges[index] = true;
}

/**
 * Process the input for a specific role
 * @param {number} index - The index of the role
 */
function processRoleInput(index) {
  console.log(`Processing input for role at index ${index}`);
  const inputElement = document.querySelector(`.name-role-${index}`);
  const newValue = inputElement.value.trim();
  
  // Perform any specific action with the new value
  console.log(`New value for role ${index}: ${newValue}`);
  
  // Update the role and re-render if necessary
  allRoles[index].name = newValue;
  roleChanges[index] = true;
  renderRoleForm();
}

function changeEmoji(index) {
  const role = allRoles[index];

  const emojiButton = document.querySelector(`.emoji-button-${index}`);

  const handleEmojiSelectionChange = (selectedEmoji) => {
    if (selectedEmoji) {
      console.log(`Selected emoji for role ${role.name}:`, selectedEmoji);
      role.emoji = selectedEmoji;
      markRoleAsChanged(index);
      renderRoleForm();
    } else {
      console.log(`No emoji selected for role ${role.name}.`);
    }
  };

  createEmojiPicker(emoji, emojiButton, index, handleEmojiSelectionChange);
}


/**
 * Delete a role and show the store button
 * @param {number} index - The index of the role
 */
function deleteRoleAndShowStoreButton(index) {
  console.log(`Deleting role at index ${index}`);

  allRoles[index].emoji = '❓';
  allRoles[index].name = '?';
  roleChanges[index] = true;

  renderRoleForm();
}

function storeRole(index) {
  const role = allRoles[index];
  roleChanges[index] = false;

  const inputElement = document.querySelector(`.name-role-${index}`);
  const newName = inputElement.value.trim();

  role.name = newName || '?';

  console.log(`Role at index ${index} stored:`, role);

  generateRoleCSV();
}


export { renderRoleForm };