const dayOff = {
    vacation: ["🛫", "🏖️", "🌍"], // Urlaub
    sickLeave: ["💉", "🩹", "🚑"], // Krankheit
    specialLeave: ["🎁", "🎂", "🎉"], // Sonderurlaub (Hochzeit, Beerdigung, etc.)
    overtimeCompensation: ["⚖️", "⏰", "📝"], // Überstunden-Ausgleich
    businessTrip: ["💼", "🚕", "🚚"], // Dienstreise
    parentalLeave: ["👶", "🍼", "🧸" ] // Mutterschutz, elternzeit
  };

  const vacationStatuses = [
    { label: 'Genehmigt', icon: '✔️', color: '#2ecc71' }, // Approved (green)
    { label: 'Ausstehend', icon: '⏳', color: '#f1c40f' }, // Pending (yellow)
    { label: 'Abgelehnt', icon: '❌', color: '#e74c3c' }, // Rejected (red)
    { label: 'Konflikt', icon: '⚠️', color: '#e67e22' } // Conflict (orange)
  ];
  