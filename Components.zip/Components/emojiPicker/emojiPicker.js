export function createEmojiPicker(emojiArray, targetButton, index, callback) {
    // Check if an emoji picker already exists
    const existingPicker = document.querySelector('.emoji-picker');
    if (existingPicker) {
        existingPicker.remove();  // Remove the existing emoji picker if any
    }

    // Calculate the grid dimensions based on the number of emojis
    let n = 0;
    while (n * n < emojiArray.length) {
      n++;
    }
  
    const emojiPickerRow = n;
    const emojiPickerCol = n;
  
    // Create the emoji picker container
    const emojiPicker = document.createElement('div');
    emojiPicker.classList.add('emoji-picker');
  
    // Create the top bar container
    const topBarWrapper = document.createElement('div');
    topBarWrapper.classList.add('top-bar-wrapper');
    topBarWrapper.setAttribute('data-index', index);
  
    // Create the top bar with close button
    const topBar = document.createElement('div');
    topBar.classList.add('top-bar');
    topBar.textContent = 'Emoji ';  // Title for the window-like bar
  
    // Create the close button inside the top bar
    const closeButton = document.createElement('button');
    closeButton.classList.add('close-btn');
    closeButton.textContent = '×';
    closeButton.onclick = () => emojiPicker.remove();  // Close the picker when clicked
    topBar.appendChild(closeButton);
  
    // Add the top bar to the wrapper and the wrapper to the emoji picker
    topBarWrapper.appendChild(topBar);
    emojiPicker.appendChild(topBarWrapper);
  
    // Create the emoji grid container
    const emojiGrid = document.createElement('div');
    emojiGrid.classList.add('emoji-grid');
  
    // Create emoji grid
    let emojiIndex = 0;
    for (let row = 0; row < emojiPickerRow; row++) {
      for (let col = 0; col < emojiPickerCol; col++) {
        const emoji = emojiArray[emojiIndex++];
        if (!emoji) break;  // If we run out of emojis, stop
  
        const emojiButton = document.createElement('div');
        emojiButton.classList.add('emoji');
        emojiButton.textContent = emoji;
  
        // Add dynamic row and column classes
        emojiButton.classList.add(`row-${row}`);
        emojiButton.classList.add(`col-${col}`);
  
        // Dynamically set the data-index attribute
        emojiButton.setAttribute('data-index', emojiIndex - 1);
  
        // Ensure the correct hover color is applied
        emojiButton.style.setProperty(`--role-${emojiIndex - 1}-color`, `var(--role-${index}-color)`);
  
        emojiButton.onclick = () => handleEmojiSelection(emoji, emojiPicker, callback);

        emojiGrid.appendChild(emojiButton);
      }
    }
  
    // Add the emoji grid to the emoji picker
    emojiPicker.appendChild(emojiGrid);
  
    // Calculate the height and width based on the number of rows and columns
    const emojiPickerHeight = emojiPickerRow * 24;  // Each emoji is 24px high
    const emojiPickerWidth = emojiPickerCol * 24;   // Each emoji is 24px wide
  
    // Position the picker relative to the calling button (with an offset)
    const rect = targetButton.getBoundingClientRect();
    emojiPicker.style.top = `${rect.bottom + (-n * 25)}px`;  // Adjust top based on the number of rows
    emojiPicker.style.left = `${rect.left + window.scrollX + (-n * 25)}px`;  // Offset the picker left and center it
    
    document.body.appendChild(emojiPicker);
  
    // Mouseleave to close the emoji picker when cursor leaves
    // emojiPicker.addEventListener('mouseleave', () => {
    //     callback(null);
    //     emojiPicker.remove();
    // });
  
    //const closeAfterTimeLimit = 10000; 
    // setTimeout(() => {
    //     callback(null);
    //     emojiPicker.remove();
    // }, closeAfterTimeLimit);
}

function handleEmojiSelection(emoji, pickerElement, callback) {
    callback(emoji);  // Pass the selected emoji to the callback
    pickerElement.remove();  // Close the picker after selection
}
