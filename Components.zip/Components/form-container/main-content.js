// main-content.js

// Function to load the HTML content into the main container
function loadMainContent() {
  const mainContentUrl = 'components/main-content/main-content.html';
  const mainContentContainer = document.getElementById('main-content-container');

  fetch(mainContentUrl)
    .then(response => response.text())
    .then(data => {
      mainContentContainer.innerHTML = data; // Insert the content into the container
      initializeMainContent(); // Call an initialization function after loading
    })
    .catch(error => console.error('Error loading main content:', error));
}

// Function to initialize specific behavior for the main content
function initializeMainContent() {
  // Add any event listeners or interactivity for the loaded content
  console.log('Main content initialized.');
  insertCalendarHeader()
}

// Load the main content when the script is executed
document.addEventListener('DOMContentLoaded', loadMainContent);

// Create Calendar Header Element
function createCalendarHeader() {
  const calendarHeader = document.createElement('div');
  calendarHeader.classList.add('calendar-header');

  // Create "Previous" Button
  const prevButton = document.createElement('button');
  prevButton.classList.add('mybutton', 'previous');
  prevButton.textContent = 'Prev';
  prevButton.addEventListener('click', () => {
    // Logic for previous month/year
    console.log('Previous Month');
  });

  // Create Month Dropdown
  const monthDropdown = document.createElement('select');
  monthDropdown.classList.add('month-dropdown');
  const months = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];
  months.forEach((month, index) => {
    const monthOption = document.createElement('option');
    monthOption.value = index;
    monthOption.textContent = month;
    monthDropdown.appendChild(monthOption);
  });

  // Create "Next" Button
  const nextButton = document.createElement('button');
  nextButton.classList.add('mybutton', 'next');
  nextButton.textContent = 'Next';
  nextButton.addEventListener('click', () => {
    // Logic for next month/year
    console.log('Next Month');
  });

  // Create Year Label
  const yearLabel = document.createElement('span');
  yearLabel.classList.add('year-label');
  yearLabel.textContent = '2024';

  // Create Toggle View Button
  const toggleButton = document.createElement('button');
  toggleButton.classList.add('mybutton', 'toggle-view');
  toggleButton.textContent = 'Toggle View';
  toggleButton.addEventListener('click', () => {
    // Logic to toggle between "Anwesend" and "Abwesend"
    console.log('Toggle View');
  });

  // Append all elements to the calendarHeader container
  calendarHeader.appendChild(prevButton);
  calendarHeader.appendChild(monthDropdown);
  calendarHeader.appendChild(nextButton);
  calendarHeader.appendChild(yearLabel);
  calendarHeader.appendChild(toggleButton);

  return calendarHeader;
}

// Function to insert the calendar header into the DOM
function insertCalendarHeader() {
  const calendarContainer = document.getElementById('calendar');
  const calendarHeader = createCalendarHeader();
  calendarContainer.appendChild(calendarHeader);
}

// Call the function to render the header on page load
window.onload = insertCalendarHeader;
