import { loadRoleData, roles , allRoles} from '../../js/loader/role-loader.js';
import { loadEmployeeData, employees } from '../../js/loader/employee-loader.js';
import { loadCalendarData, state, companyHolidays, officeDays, schoolHoliday } from '../../js/loader/calendar-loader.js';
import { getHolidayDetails, nonOfficialHolidays, monthNames, germanFixedHolidays, germanVariableHolidays } from '../../js/Utils/holidayUtils.js';
import { stateFlags, updateStateFlag } from '../../js/Utils/flagUtils.js';

let currentMonthIndex;
let currentYear;
let weeks;

document.addEventListener('DOMContentLoaded', () => {
  
  Promise.all([
    loadRoleData(),       // Load role data
    loadEmployeeData(),   // Load employee data
    loadCalendarData()    // Load calendar data (holidays, etc.)
  ])
    .then(() => {
      // Once all data is loaded, initialize the calendar and render the month
      initializeCalendar();
      const calendarContainer = document.getElementById('calendar'); 
      
      // Generate the calendar for the current month
      const weeks = generateCalendar(currentMonthIndex, currentYear);

      // Render the calendar month
      renderCalendarMonth(calendarContainer);
    })
    .catch((error) => {
      console.error('Error loading data:', error);
    });
});

function initializeCalendar() {
  const currentDate = new Date();
  currentMonthIndex = currentDate.getMonth(); 
  currentYear = currentDate.getFullYear(); 
  
  const calendarHeader = createCalendarHeader();
  const calendarContainer = document.getElementById('calendar'); // Assuming you have a calendar container
  
  calendarContainer.appendChild(calendarHeader);
  
  const monthElement = document.getElementById('calendar-month');
  const yearElement = document.getElementById('calendar-year');
  const prevMonthButton = document.getElementById('prev-month');
  const nextMonthButton = document.getElementById('next-month');
  const prevYearButton = document.getElementById('prev-year');
  const nextYearButton = document.getElementById('next-year');

  prevMonthButton.addEventListener('click', () => {
    if (currentMonthIndex === 0) {
      if (currentYear > 2025) {
        currentMonthIndex = 11;
        currentYear--;
      }
    } else {
      currentMonthIndex--;
    }
    generateAndRenderCalendar();
  });

  nextMonthButton.addEventListener('click', () => {
    if (currentMonthIndex === 11) {
      if (currentYear < 2030) {
        currentMonthIndex = 0;
        currentYear++;
      }
    } else {
      currentMonthIndex++;
    }
    updateCalendarDisplay(monthElement, yearElement);
  });

  prevYearButton.addEventListener('click', () => {
    if (currentYear > 2025) {
      currentYear--;
      updateCalendarDisplay(monthElement, yearElement);
    }
  });

  nextYearButton.addEventListener('click', () => {
    if (currentYear < 2030) {
      currentYear++;
      updateCalendarDisplay(monthElement, yearElement); 
    }
  });
}

function updateCalendarDisplay(monthElement, yearElement) {
  generateAndRenderCalendar();
  monthElement.textContent = monthNames[currentMonthIndex];
  yearElement.textContent = currentYear;
}

function generateAndRenderCalendar() {
  weeks = generateCalendar(currentMonthIndex, currentYear);
  const calendarContainer = document.getElementById('calendar'); 
  calendarContainer.innerHTML = "";
  calendarContainer.appendChild(createCalendarHeader());
  renderCalendarMonth(calendarContainer); 
}

function generateCalendar(month, year) {
  const firstDay = new Date(year, month, 1);
  const firstDayOfWeek = (firstDay.getDay() + 6) % 7; // Shift Sunday (0) to Monday (0)
  const lastDay = new Date(year, month + 1, 0);
  const totalDays = lastDay.getDate(); 
  
  const weeks = [];
  let currentWeek = [];
  let weekNumber = getWeekNumber(firstDay);
  
  // Fill the first week with empty slots until the first day
  for (let i = 0; i < firstDayOfWeek; i++) {
    currentWeek.push('');
  }

  // Fill the calendar with the actual days
  for (let day = 1; day <= totalDays; day++) {
    currentWeek.push(day);
    if (currentWeek.length === 7) {
      weeks.push({ weekNumber, days: [...currentWeek] });
      currentWeek = [];
      weekNumber++;
    }
  }

  // Add the remaining days to the last week
  if (currentWeek.length > 0) {
    weeks.push({ weekNumber, days: [...currentWeek] });
  }

  return weeks;
}


function getWeekNumber(date) {
  const tempDate = new Date(date);
  tempDate.setDate(tempDate.getDate() - tempDate.getDay() + 3); // Set to Thursday
  const firstThursday = new Date(tempDate.getFullYear(), 0, 1);
  return Math.ceil(((tempDate - firstThursday) / 86400000 + 1) / 7);
}

function createCalendarHeader() {
  
  const stateImage = document.createElement('img');
  stateImage.classList.add('state-image', 'stateIcon');

  if (state) {
    updateStateFlag(state, stateImage);
  } else {
    console.warn('No state selected, cannot render flag.');
  }

  const calendarHeader = document.createElement('div');
  calendarHeader.classList.add('calendar-header');

  const prevMonthButton = document.createElement('button');
  prevMonthButton.classList.add('mybutton', 'previous');
  prevMonthButton.id = 'prev-month';
  prevMonthButton.textContent = '⏪';

  const nextMonthButton = document.createElement('button');
  nextMonthButton.classList.add('mybutton', 'next');
  nextMonthButton.id = 'next-month';
  nextMonthButton.textContent = '⏩';

  const monthLabel = document.createElement('span');
  monthLabel.classList.add('month-label');
  monthLabel.id = 'calendar-month';
  monthLabel.textContent = monthNames[currentMonthIndex];

  const prevYearButton = document.createElement('button');
  prevYearButton.classList.add('mybutton', 'previous');
  prevYearButton.id = 'prev-year';
  prevYearButton.textContent = '⏪';

  const nextYearButton = document.createElement('button');
  nextYearButton.classList.add('mybutton', 'next');
  nextYearButton.id = 'next-year';
  nextYearButton.textContent = '⏩';

  const yearLabel = document.createElement('span');
  yearLabel.classList.add('year-label');
  yearLabel.id = 'calendar-year';
  yearLabel.textContent = currentYear;

  const toggleButton = document.createElement('span');
  toggleButton.classList.add('toggle-attendance');
  toggleButton.id = 'toggle-attendance';
  toggleButton.textContent = 'Anwesend';

  toggleButton.addEventListener('click', () => {
    if (toggleButton.textContent === 'Anwesend') {
      toggleButton.textContent = 'Abwesend';
      toggleButton.style.backgroundColor = 'crimson';
    } else {
      toggleButton.textContent = 'Anwesend';
      toggleButton.style.backgroundColor = 'cornflowerblue';
    }
  });

  const updateCalendarHeader = () => {
    calendarHeader.innerHTML = ""; 

    calendarHeader.appendChild(stateImage);
    if (currentYear > 2025 || currentMonthIndex !== 0) {
      calendarHeader.appendChild(prevMonthButton);
    }
    calendarHeader.appendChild(monthLabel);

    if (currentYear < 2030 || currentMonthIndex < 11) {
      calendarHeader.appendChild(nextMonthButton);
    }
    
    calendarHeader.appendChild(toggleButton);

    if (currentYear => 2024) {
      calendarHeader.appendChild(prevYearButton);
    }
    calendarHeader.appendChild(yearLabel);

    if (currentYear < 2030) {
      calendarHeader.appendChild(nextYearButton);
    }

  };

  prevMonthButton.addEventListener('click', () => {
    if (currentMonthIndex === 0 && currentYear > 2025) {
      currentMonthIndex = 11;
      currentYear--;
    } else {
      currentMonthIndex--;
    }
    updateCalendarHeader();
    updateCalendarDisplay(monthLabel, yearLabel);
    generateAndRenderCalendar();
  });

  nextMonthButton.addEventListener('click', () => {
    if (currentMonthIndex === 11 && currentYear < 2030) {
      currentMonthIndex = 0;
      currentYear++;
    } else {
      currentMonthIndex++;
    }
    updateCalendarHeader(); 
    updateCalendarDisplay(monthLabel, yearLabel);
    generateAndRenderCalendar();
  });

  prevYearButton.addEventListener('click', () => {
    if (currentYear > 2025) {
      currentYear--;
      updateCalendarHeader(); 
      updateCalendarDisplay(monthLabel, yearLabel);
      generateAndRenderCalendar();
    }
  });

  nextYearButton.addEventListener('click', () => {
    if (currentYear < 2030) {
      currentYear++;
      updateCalendarHeader();
      updateCalendarDisplay(monthLabel, yearLabel);
      generateAndRenderCalendar();
    }
  });

  updateCalendarHeader();
  return calendarHeader;
}



function renderCalendarMonth(calendarContainer) {
  
  const headerRow = document.createElement('div');
  headerRow.classList.add('calendar-weekday-header');

  const daysOfWeek = ['KW', 'Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'];
  daysOfWeek.forEach(day => {
    const headerCell = document.createElement('div');
    headerCell.textContent = day;
    headerCell.className = day === 'KW' ? 'kw-column' : 'day-column';
    if (day === 'So') {
      headerCell.classList.add('sunday');
    }
    headerRow.appendChild(headerCell);
  });

  calendarContainer.appendChild(headerRow);

  // Render weeks
  weeks.forEach(week => {
    const weekRow = document.createElement('div');
    weekRow.classList.add('calendar-row');

    // KW column
    const kwCell = document.createElement('div');
    kwCell.textContent = `KW ${week.weekNumber}`;
    kwCell.className = 'kw-column';
    weekRow.appendChild(kwCell);

    // Day columns
    week.days.forEach((day, index) => {
      const dayCell = document.createElement('div');
      dayCell.className = 'day-column';
      if (index === 6) {
        dayCell.classList.add('sunday'); // Highlight Sundays
      }
      
      const topRow = document.createElement('div');
      topRow.className = 'day-column-top';
      
      // Add day number
      const dayNumber = document.createElement('div');
      dayNumber.className = 'day-number';
      dayNumber.textContent = day || ''; // Empty cell for non-days
      topRow.appendChild(dayNumber);
    
      // Placeholder for warnings
      const warningIndicator = document.createElement('div');
      warningIndicator.className = 'warning-indicator';
      warningIndicator.textContent = ''; // No warning by default
      topRow.appendChild(warningIndicator);
    
      // Placeholder for special days
      const specialDay = document.createElement('div');
      specialDay.className = 'special-day';
      
      // Check for holidays
  
      // Check for office days and apply appropriate styles
      if (day) {
        const fullDate = `${currentYear}-${String(currentMonthIndex + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        
        // Check for public holiday first
        const holidayDetails = getHolidayDetails(fullDate, state); // Get public holiday details
        
        if (holidayDetails) {
          specialDay.textContent = holidayDetails.emoji; // Add public holiday emoji
          specialDay.title = holidayDetails.name; // Tooltip for the holiday name
          dayCell.classList.add('holiday'); // Add class for public holiday styling
          dayCell.style.backgroundColor = 'tomato'; // Highlight public holiday cells
        } else {
          // Check for company holiday (Betriebsferien) if no public holiday found
          const companyHoliday = getCompanyHoliday(fullDate); // Check for company holiday
          if (companyHoliday) {
            specialDay.textContent = '🔒'; // Padlock emoji for company holidays
            specialDay.title = 'Betriebsferien'; // Tooltip text for company holidays
            dayCell.classList.add('closed-office'); // Add class for closed office
            dayCell.style.backgroundColor = '#F08080'; // Light Coral for company holidays
          } else {
            // Check if it's an office day and the shift type
            const dayOfWeek = (new Date(fullDate).getDay() + 6) % 7;
            const officeShift = officeDays[dayOfWeek]; // Get the office shift for the day
            
            // If it's a "day off" (not Sunday), highlight in light coral
            if (officeShift === 'never') {
              specialDay.textContent = ''; // No emoji for days off
              specialDay.title = 'Day off'; // Tooltip for days off
              dayCell.classList.add('day-off'); // Add day off class
            }
            // If it's a half-day ("morning" or "afternoon"), render small coral band
            else if (officeShift === 'morning' || officeShift === 'afternoon') {
              specialDay.textContent = ''; // No emoji for half-day
              specialDay.title = `${officeShift.charAt(0).toUpperCase() + officeShift.slice(1)} shift`; // Tooltip for half-day shift
              
              // Add appropriate class for the half-day shift type
              dayCell.classList.add(`${officeShift}-shift`); // Adds 'morning-shift' or 'afternoon-shift'
              
              // Dynamically create a band for half-day shifts
              const band = document.createElement('div');
              band.classList.add('half-shift-band');
              dayCell.appendChild(band);
            } else {
              // Full day shift (normal workday)
              specialDay.textContent = ''; // No emoji
              specialDay.title = `${officeShift.charAt(0).toUpperCase() + officeShift.slice(1)} shift`; // Tooltip for full-day shift
              dayCell.classList.add('full-shift'); // Add class for full day shifts
            }
            
          }
        }
      }
      if ( specialDay === null || specialDay == ""){
        const schoolHolidayDetails = getSchoolHoliday(fullDate);  // Get school holiday details
        
        if (schoolHolidayDetails) {
          specialDay.textContent = schoolHolidayDetails.emoji;   // Add school holiday emoji
          specialDay.title = schoolHolidayDetails.tooltipText;   // Set tooltip text for school holiday
        }
      }
    
      topRow.appendChild(specialDay);
      dayCell.appendChild(topRow);
      weekRow.appendChild(dayCell); // Assuming weekRow is the parent container for days
    });
    calendarContainer.appendChild(weekRow);
  });
}

function getCompanyHoliday(date) {
  // Loop through the company holidays (loaded dynamically)
  for (const holiday of companyHolidays) {
    const holidayStart = new Date(holiday.startDate); // Start date of the holiday range
    const holidayEnd = new Date(holiday.endDate);     // End date of the holiday range
    const targetDate = new Date(date);                // Target date to check

    // Check if the target date is within the holiday range
    if (targetDate >= holidayStart && targetDate <= holidayEnd) {
      return true; // Date matches a company holiday
    }
  }
  return false; // No company holiday for this date
}

function getSchoolHoliday(date) {
  for (const holiday of schoolHoliday) {
    const holidayStart = new Date(holiday.startDate); 
    const holidayEnd = new Date(holiday.endDate);     
    const targetDate = new Date(date);                
    
    const isHolidayInState = holiday.bundesländer.includes(state) || holiday.bundesländer.includes('All States');
    if (targetDate >= holidayStart && targetDate <= holidayEnd && isHolidayInState) {
      return {
        emoji: holiday.emoji,              
        tooltipText: holiday.name
      };
    }
  }
  return null;
}

