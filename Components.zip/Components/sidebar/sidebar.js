import { renderRoleForm } from '../forms/role-form/role-form2.js'; 
import { initializeEmployeeForm } from '../forms/employee-form/employee-form.js';
import { initializeCalendarForm } from '../forms/calendar-form/calendar-form.js';

document.addEventListener('DOMContentLoaded', () => {
  initializeSidebar();
});

function initializeSidebar() {
  const sidebar = document.getElementById('sidebar');
  const formContainer = document.getElementById('form-container');

  if (!sidebar) return console.error('Sidebar not found');
  if (!formContainer) return console.error('Form container not found');

  const buttonsConfig = [
    { id: 'request-button', text: 'Anträge', iconPath: '/assets/svg/file-document-svgrepo-com.svg' },
    { id: 'employee-button', text: 'Mitarbeiter', iconPath: '/assets/svg/person-team-svgrepo-com.svg' },
    { id: 'role-button', text: 'Aufgaben', iconPath: '/assets/svg/puzzle-piece-svgrepo-com.svg' },
    { id: 'rule-button', text: 'Regeln', iconPath: '/assets/svg/knowledge-graph-relationship-svgrepo-com.svg' },
    { id: 'calendar-button', text: 'Kalender', iconPath: '/assets/svg/calendar-svgrepo-com.svg'},
    { id: 'admin-button', text: 'Werkzeuge', iconPath: '/assets/svg/cog-wheel-settings-svgrepo-com.svg'},
  ];
  buttonsConfig.forEach(config => {
    const button = document.createElement('button');
    button.id = config.id;
    button.className = 'nav-button';
  
    const icon = document.createElement('img');
    icon.src = config.iconPath;
    icon.alt = `${config.text} Icon`;
    icon.className = 'nav-icon';
  
    const text = document.createElement('span');
    text.textContent = config.text;
  
    button.appendChild(icon);
    button.appendChild(text);
  
    button.addEventListener('click', function () {
      updateFeedback('Sidebar button clicked:', this.id);
  
      const buttonId = this.id;
      const url = new URL(window.location.href);
  
      console.log('Current URL:', window.location.href);
  
      url.searchParams.set('form', buttonId);
  
      console.log('Updated URL:', url.href);
  
      window.history.pushState({}, '', url);
  
      loadForm(buttonId);
    });
  
    sidebar.appendChild(button);
  });
  

  const urlParams = new URLSearchParams(window.location.search);
  const formType = urlParams.get('form') || 'request-button';
  loadForm(formType);
}
function loadForm(formType) {
  const formContainer = document.getElementById('form-container');
  formContainer.innerHTML = '';
  let formUrl = '';
  switch (formType) {
    case 'employee-button':
      formUrl = 'components/forms/employee-form/employee-form.html';
      break;
    case 'request-button':
      formUrl = 'components/forms/request-form/request-form.html';
      break;
    case 'admin-button':
      formUrl = 'components/forms/admin-form/admin-form.html';
      break;
    case 'calendar-button':
      formUrl = 'components/forms/calendar-form/calendar-form.html';
      break;
    case 'role-button':
      formUrl = 'components/forms/role-form/role-form.html';
      break;
    case 'rule-button':
      formUrl = 'components/forms/rule-form/rule-form.html';
      break;
    default:
      formContainer.innerHTML = `<p style="color: red; text-align: center; font-weight: bold;">Keine Funktion ausgewählt!</p>`;
      return; 
  }

  fetch(formUrl)
  .then((response) => {
    if (!response.ok) {
      throw new Error(`Failed to load form: ${formUrl}`);
    }
    return response.text();
  })
  .then((htmlContent) => {
    const formContainer = document.getElementById('form-container');
    if (!formContainer) {
      console.error('form-container not found!');
      return;
    }

    formContainer.innerHTML = htmlContent;

    // Handle different form types
    switch (formType) {
      case 'role-button':
        const roleContainer = document.getElementById('role-form-container');
        if (roleContainer) {
          renderRoleForm(); // Now safe to call
        } else {
          console.error('role-form-container not found!');
        }
        break;

      case 'employee-button': // Replace with actual form types
        const employeeContainer = document.getElementById('employee-form-container');
        if (employeeContainer) {
          initializeEmployeeForm()
        } else {
          console.error('role-form-container not found!');
        }
        break;
        case 'calendar-button': // Replace with actual form types
        const calendarFormContainer = document.getElementById('calendar-form-container');
        if (calendarFormContainer ) {
          initializeCalendarForm()
        } else {
          console.error('role-form-container not found!');
        }
        break;
      default:
        console.warn(`Unknown formType: ${formType}`);
        break;
    }
  })
  .catch((error) => {
    console.error('Error loading form:', error);
    const formContainer = document.getElementById('form-container');
    if (formContainer) {
      formContainer.innerHTML = `
        <p style="color: red; text-align: center; font-weight: bold;">
          Fehler beim Laden des Formulars.
        </p>`;
    }
  });

}


