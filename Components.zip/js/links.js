
// css
import './css.js';

// General JavaScript

import './main.js';
import './resizer.js';

import '../Components/sidebar/sidebar.js';
import '../Components/legend/legend.js';
import '../Components/calendar/calendar.js';
import '../Components/emojiPicker/emojiPicker.js';
import '../Components/Slider/slider.js';
// import '../components/main-Content/main-content.js';

// forms
// import '../components/forms/request-form/request-form.js';
import '../Components/forms/role-form/role-form2.js';
// import '../components/forms/employee-form/employee-form.js';
// import '../components/forms/rule-form/rule-form.js';
// import '../components/forms/calendar-form/calendar-form.js';
// import '../components/forms/admin-form/admin-form.js';

// loader
import './loader/role-loader.js';
import './loader/employee-loader.js';
  