// Dynamically load CSS files
const cssFiles = [
    'styles/global.css', // Global CSS
    'Components/sidebar/sidebar.css', // Sidebar CSS
    'Components/legend/legend.css', // Legend CSS
    'Components/calendar/calendar.css', // Calendar CSS
    'Components/form-container/form-container.css', // Main Content CSS
    'Components/emojiPicker/emojiPicker.css',
    'Components/Slider/slider.css',
  
    'assets/css/colors.css',
    'assets/css/buttons.css',
    'assets/css/icons.css',
     // Forms CSS
    'Components/forms/role-form/role-form.css',
    'Components/forms/rule-form/rule-form.css',
    'Components/forms/calendar-form/calendar-form.css',
    'Components/forms/admin-form/admin-form.css',
    'Components/forms/request-form/request-form.css',
    'Components/forms/employee-form/employee-form.css',
    ];
  
  // Function to load CSS files dynamically
  cssFiles.forEach(function (cssFile) {
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = cssFile;
    document.head.appendChild(link);
  });
  