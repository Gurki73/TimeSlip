let roles = [];     // Holds the filtered role data globally
let allRoles = [];  // Holds all roles globally

/**
 * Load role data from a CSV file and populate roles arrays.
 * @returns {Promise<void>}
 */
function loadRoleData() {
    return new Promise((resolve, reject) => {
        fetch('../../data/role.csv')  // Adjust the path as necessary
            .then(response => response.text())
            .then(data => {
                parseCSV(data);  // Parse and update roles arrays
                resolve();  // Resolve the promise once data is loaded
            })
            .catch(error => {
                console.error('Error loading role data:', error);
                reject(error);  // Reject the promise if an error occurs
            });
    });
}

/**
 * Parse CSV data and populate global roles arrays.
 * @param {string} data - The CSV data as a string
 */
function parseCSV(data) {
    const rows = data.split('\n');
    
    allRoles = rows.slice(1).map(row => {
        const [name, colorIndex, emoji] = row.split(',');
        return {
            name: name?.trim(),
            colorIndex: colorIndex?.trim(),
            emoji: emoji?.trim()
        };
    });
    roles = allRoles.filter(role => role.name && role.name !== '?');
}

function isFileSystemAccessSupported() {
    return 'showSaveFilePicker' in window;
}

async function generateRoleCSV() {
    const csvHeader = 'name,colorIndex,emoji';
    const csvContent = [
        csvHeader,
        ...allRoles.map(role => `${role.name || '?'},${role.colorIndex || 0},${role.emoji || '❓'}`)
    ].join('\n');

    const uniqueFileName = generateUniqueFileName('role.csv'); // Generate unique file name

    if (isFileSystemAccessSupported()) {
        try {
            const handle = await window.showSaveFilePicker({
                suggestedName: uniqueFileName,
                types: [{
                    description: 'CSV Files',
                    accept: { 'text/csv': ['.csv'] }
                }],
            });

            const writableStream = await handle.createWritable();
            await writableStream.write(csvContent);
            await writableStream.close();
            console.log('File saved successfully using File System Access API');
        } catch (err) {
            console.error('Error saving file using File System Access API:', err);
            fallbackDownload(csvContent);
        }
    } else {
        console.log('File System Access API not supported. Falling back to Blob download.');
        showFallbackMessage();
        fallbackDownload(csvContent, uniqueFileName); 
    }
}

function generateUniqueFileName(defaultFileName) {
    // Get the base URL, remove the protocol and path to just have the hostname or IP
    const baseURL = window.location.origin;  // Example: http://localhost:3000 or https://example.com
    const pathname = window.location.pathname.split('/'); // Example: ['/', 'Urlaubsplaner', 'index.html']
    const folderPath = pathname.slice(1, -1).join('/'); // We exclude the last part (index.html)

    // Combine base URL or hostname with relative path to create a unique file path
    const uniquePath = folderPath ? `${folderPath}/data/${defaultFileName}` : `data/${defaultFileName}`;

    return uniquePath;
}

function fallbackDownload(content, uniqueFileName) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = uniqueFileName;  // Use unique filename here
    a.click();

    URL.revokeObjectURL(url);
    console.log('Role CSV downloaded successfully.');
}

function showFallbackMessage() {
    
    const messageElement = document.createElement('div');
    messageElement.style.padding = '10px';
    messageElement.style.backgroundColor = '#f8d7da';
    messageElement.style.border = '1px solid #f5c6cb';
    messageElement.style.color = '#721c24';
    messageElement.style.margin = '10px 0';
    messageElement.style.borderRadius = '5px';
    messageElement.innerHTML = `
        <strong>Notice:</strong> The File System Access API is not supported in your browser.
        <br>Please use a Chromium-based browser (e.g., Chrome) for better file management,
        or move the downloaded file to the desired folder manually.
    `;

    document.body.appendChild(messageElement);
}


export { loadRoleData, roles, allRoles, generateRoleCSV };
