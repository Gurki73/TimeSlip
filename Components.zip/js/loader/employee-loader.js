let employees = [];  // Holds employee data globally

/**
 * Load employee data from a CSV file and populate employees array.
 * @returns {Promise<void>}
 */
function loadEmployeeData() {
    return new Promise((resolve, reject) => {
        fetch('../../data/employee.csv')  // Adjust the path as necessary
            .then(response => response.text())
            .then(data => {
                parseCSV(data);  // Parse and update employees array
                resolve();  // Resolve the promise once data is loaded
            })
            .catch(error => {
                console.error('Error loading employee data:', error);
                reject(error);  // Reject the promise if an error occurs
            });
    });
}

/**
 * Parse CSV data and populate the global employees array.
 * @param {string} data - The CSV data as a string
 */
function parseCSV(data) {
    const rows = data.split('\n');
    
    // Parse all employees, skipping the header
    employees = rows.slice(1).map(row => {
        const [
            id,
            name,
            personalEmoji,
            mainRoleIndex,
            secondaryRoleIndex,
            tertiaryRoleIndex,
            availableDaysOff,
            remainingDaysOff,
            overtime,
            mon,
            tue,
            wed,
            thu,
            fri,
            sat,
            sun,
            roleSplitMain,
            roleSplitSecondary,
            roleSplitTertiary,
            startDate,
            endDate,
            teamIndex,
            shiftType,
            birthday, // Added birthday field
            shiftMon,
            shiftTue,
            shiftWed,
            shiftThu,
            shiftFri,
            shiftSat,
            shiftSun // Added shifts for each day
        ] = row.split(',');

        return {
            id: parseInt(id),  // If id is numeric
            name,
            personalEmoji,  // This is the actual personal emoji (⚽, ❤️, etc.)
            mainRoleIndex: mainRoleIndex ? parseInt(mainRoleIndex) : null,
            secondaryRoleIndex: secondaryRoleIndex ? parseInt(secondaryRoleIndex) : null,
            tertiaryRoleIndex: tertiaryRoleIndex ? parseInt(tertiaryRoleIndex) : null,
            availableDaysOff: parseFloat(availableDaysOff),
            remainingDaysOff: parseFloat(remainingDaysOff),
            overtime: parseFloat(overtime),
            workDays: [mon, tue, wed, thu, fri, sat, sun].map(day => day === 'true'),  // Convert to boolean for workdays
            roleSplitMain: parseFloat(roleSplitMain),
            roleSplitSecondary: parseFloat(roleSplitSecondary),
            roleSplitTertiary: parseFloat(roleSplitTertiary),
            startDate,
            endDate,
            teamIndex: teamIndex || null,  // Null if team index is not available
            shiftType,
            birthday,  // Store birthday as dd.mm
            shifts: {  // Store shift types for each day of the week
                mon: shiftMon,
                tue: shiftTue,
                wed: shiftWed,
                thu: shiftThu,
                fri: shiftFri,
                sat: shiftSat,
                sun: shiftSun
            }
        };
    }).filter(employee => employee.name && employee.name !== '?');  // Filter out invalid employees
}

/**
 * Check if File System Access API is supported.
 * @returns {boolean} - Returns true if File System Access API is supported.
 */
function isFileSystemAccessSupported() {
    return 'showSaveFilePicker' in window;
}

/**
 * Generate CSV content for employee data and save to file.
 */
async function generateEmployeeCSV() {
    const csvHeader = 'id,name,personalEmoji,mainRoleIndex,secondaryRoleIndex,tertiaryRoleIndex,availableDaysOff,remainingDaysOff,overtime,mon,tue,wed,thu,fri,sat,sun,roleSplitMain,roleSplitSecondary,roleSplitTertiary,startDate,endDate,teamIndex,shiftType,birthday,shiftMon,shiftTue,shiftWed,shiftThu,shiftFri,shiftSat,shiftSun';
    
    const csvContent = [
        csvHeader,
        ...employees.map(employee => {
            return `${employee.id},${employee.name},${employee.personalEmoji},${employee.mainRoleIndex || '?'},${employee.secondaryRoleIndex || '?'},${employee.tertiaryRoleIndex || '?'},${employee.availableDaysOff},${employee.remainingDaysOff},${employee.overtime},${employee.workDays[0]},${employee.workDays[1]},${employee.workDays[2]},${employee.workDays[3]},${employee.workDays[4]},${employee.workDays[5]},${employee.workDays[6]},${employee.roleSplitMain},${employee.roleSplitSecondary},${employee.roleSplitTertiary},${employee.startDate},${employee.endDate},${employee.teamIndex || '?'},${employee.shiftType},${employee.birthday},${employee.shifts.mon},${employee.shifts.tue},${employee.shifts.wed},${employee.shifts.thu},${employee.shifts.fri},${employee.shifts.sat},${employee.shifts.sun}`;
        })
    ].join('\n');

    const uniqueFileName = generateUniqueFileName('employee.csv'); // Generate unique file name

    if (isFileSystemAccessSupported()) {
        try {
            // Try to save file using File System Access API
            const handle = await window.showSaveFilePicker({
                suggestedName: uniqueFileName,  // Default filename with unique path
                types: [{
                    description: 'CSV Files',
                    accept: { 'text/csv': ['.csv'] }
                }],
            });

            const writableStream = await handle.createWritable();
            await writableStream.write(csvContent);
            await writableStream.close();
            console.log('Employee data saved successfully using File System Access API');
        } catch (err) {
            console.error('Error saving file using File System Access API:', err);
            fallbackDownload(csvContent);  // Fallback if something goes wrong
        }
    } else {
        // Fallback for browsers that don't support the File System Access API
        console.log('File System Access API not supported. Falling back to Blob download.');
        fallbackDownload(csvContent, uniqueFileName);  // Fall back to Blob download
    }
}

/**
 * Generate a unique file name based on the current URL.
 * @param {string} defaultFileName - Default file name for the CSV.
 * @returns {string} - The unique file path.
 */
function generateUniqueFileName(defaultFileName) {
    const baseURL = window.location.origin;  // Example: http://localhost:3000 or https://example.com
    const pathname = window.location.pathname.split('/');
    const folderPath = pathname.slice(1, -1).join('/'); // Excluding index.html
    const uniquePath = folderPath ? `${folderPath}/data/${defaultFileName}` : `data/${defaultFileName}`;

    return uniquePath;
}

/**
 * Fallback function for downloading CSV as Blob when File System Access API is not supported.
 * @param {string} content - The CSV content.
 * @param {string} uniqueFileName - The name for the downloaded file.
 */
function fallbackDownload(content, uniqueFileName) {
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    a.href = url;
    a.download = uniqueFileName;
    a.click();

    URL.revokeObjectURL(url);
    console.log('Employee CSV downloaded successfully.');
}

export { loadEmployeeData, employees, generateEmployeeCSV };
