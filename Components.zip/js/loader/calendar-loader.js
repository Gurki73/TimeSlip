let state = '';  // To store state data
let companyHolidays = [];  // To store company holidays
let officeDays = [];  // To store office days (as strings)
let schoolHoliday = [] // TO DO YEAR AND STATE

function loadCalendarData() {
  return Promise.all([loadStateData(), loadCompanyHolidaysData(), loadOfficeDaysData(), loadSchoolHolidayData()])
    .then(() => {
      // console.log('State:', state);
      // console.log('Company Holidays:', companyHolidays);
      // console.log('Office Days:', officeDays);
      // console.log('School Holidays:', schoolHoliday);
    })
    .catch((error) => {
      console.error('Error loading calendar data:', error);
    });
}

function loadStateData() {
  return fetch('../../data/state.txt')
    .then(response => response.text())
    .then(data => {
      state = data.trim();  // Store the state globally
    })
    .catch(error => {
      console.error('Error loading state data:', error);
    });
}

function loadCompanyHolidaysData() {
  return fetch('../../data/companyHolidays.csv')
    .then(response => response.text())
    .then(data => {
      parseCompanyHolidaysCSV(data);
    })
    .catch(error => {
      console.error('Error loading company holiday data:', error);
    });
}

function parseCompanyHolidaysCSV(data) {
  const rows = data.split('\n').slice(1);  // Skip header row
  companyHolidays = rows.map(row => {
    const [startDate, endDate] = row.split(',');
    return {
      startDate: new Date(startDate),
      endDate: new Date(endDate),
    };
  });
}

// New function to load office days from the CSV
function loadOfficeDaysData() {
  return fetch('../../data/officeDays.csv') // Correct file name casing
    .then(response => {
      if (!response.ok) {
        throw new Error(`Failed to fetch office days: ${response.statusText}`);
      }
      return response.text();
    })
    .then(data => {
      parseOfficeDaysCSV(data);
    })
    .catch(error => {
      console.error('Error loading office days data:', error);
    });
}

function parseOfficeDaysCSV(data) {
  const rows = data.split('\n').map(row => row.trim()).filter(row => row); // Trim and filter empty rows
  if (rows.length < 2) {
    console.warn('Office Days CSV is empty or missing data.');
    return;
  }

  const officeDaysRow = rows[1].split(',').map(day => day.trim());
  
  if (officeDaysRow.length !== 7) {
    console.error('Office Days CSV does not have exactly 7 days.');
    return;
  }
  officeDays = officeDaysRow;
}

function loadSchoolHolidayData() {
  return fetch('../../data/schoolHolidays.csv')
    .then(response => response.text())
    .then(data => {
      parseSchoolHolidayCSV(data);
    })
    .catch(error => {
      console.error('Error loading school holiday data:', error);
    });
}

function parseSchoolHolidayCSV(data) {
  const rows = data.split('\n').slice(1); // Skip the header row
  schoolHoliday = rows.map(row => {
    const [emoji, name, startDate, endDate, bundesländer] = row.split(',');
    return {
      emoji,
      name,
      startDate: new Date(startDate),
      endDate: new Date(endDate),
      bundesländer: bundesländer.split(','),  // Split the list of Bundesländer
    };
  });
}

function isFileSystemAccessSupported() {
  return 'showSaveFilePicker' in window;
}

async function saveStateData(currentState) {
  const fileContent = `${currentState.trim()}\n`; // Prepare state content for saving
  const fileName = 'state.txt'; // Default file name

  if (isFileSystemAccessSupported()) {
      try {
          const handle = await window.showSaveFilePicker({
              suggestedName: fileName,
              types: [
                  {
                      description: 'Text Files',
                      accept: { 'text/plain': ['.txt'] },
                  },
              ],
          });

          const writableStream = await handle.createWritable();
          await writableStream.write(fileContent);
          await writableStream.close();

          console.log('State saved successfully using File System Access API.');
      } catch (err) {
          console.error('Error saving state with File System Access API:', err);
          fallbackDownload(fileContent, fileName);
      }
  } else {
      console.log('File System Access API not supported. Falling back to Blob download.');
      fallbackDownload(fileContent, fileName);
  }
}

function fallbackDownload(content, fileName) {
  const blob = new Blob([content], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);

  const a = document.createElement('a');
  a.href = url;
  a.download = fileName;
  a.click();

  URL.revokeObjectURL(url);
  console.log('State downloaded successfully.');
}

export { loadCalendarData, saveStateData, state, companyHolidays, officeDays, schoolHoliday };
