// File: /js/utils/flagUtils.js
export const stateFlags = {
    bay: { src: './assets/png/wappen-Bayern.png', alt: 'Bayern' },
    bra: { src: './assets/png/wappen-brandenburg.png', alt: 'Brandenburg' },
    bad: { src: './assets/png/wappen-badenWuertenberg.png', alt: 'Baden-Württemberg' },
    ber: { src: './assets/png/wappen-berlin.png', alt: 'Berlin' },
    sax: { src: './assets/png/wappen-sachsen.png', alt: 'Sachsen' },
    anh: { src: './assets/png/wappen-sachsenAnhalt.png', alt: 'Saxony-Anhalt' },
    sar: { src: './assets/png/wappen-Saarland.png', alt: 'Saarland' },
    low: { src: './assets/png/wappen-niedersachsen.png', alt: 'Niedersachsen' },
    mvp: { src: './assets/png/wappen-MeVoPO.png', alt: 'Mecklenburg-Vorpommern' },
    nrw: { src: './assets/png/wappen-nrw.png', alt: 'Nordrhein Westfalen' },
    rlp: { src: './assets/png/wappen-rheinlandPfalz.png', alt: 'Rheinland Pfalz' },
    shs: { src: './assets/png/wappen-schleswigHolstein.png', alt: 'Schleswig-Holstein' },
    hes: { src: './assets/png/wappen-hessen.png', alt: 'Hessen' },
    thu: { src: './assets/png/wappen-thüringen.png', alt: 'Thüringen' },
    ham: { src: './assets/png/wappen-hamburg.png', alt: 'Hamburg' },
    bre: { src: './assets/png/wappen-bremen.png', alt: 'Bremen' },
};

export function updateStateFlag(state, stateImageElement) {
    const flag = stateFlags[state];
    if (flag) {
        stateImageElement.src = flag.src;
        stateImageElement.alt = flag.alt;
    } else {
        console.warn(`No flag found for state: ${state}`);
    }
}
