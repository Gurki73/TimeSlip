document.addEventListener('DOMContentLoaded', () => {
  const leftPanel = document.getElementById('left-panel');
  const resizeButton = document.getElementById('resize-toggle');
  const arrow = resizeButton.querySelector('.arrow');

  resizeButton.addEventListener('click', () => {
    const isExpanded = leftPanel.classList.toggle('expanded'); // Toggle expanded state
    arrow.classList.toggle('rotate', isExpanded); // Add or remove rotation class
  });
});
